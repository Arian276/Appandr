package com.sabrina.tsplayer

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.TsExtractor
import com.sabrina.tsplayer.databinding.ActivityMainBinding
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import java.net.URLEncoder

class MainActivity: ComponentActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var web: WebView
    private var player: ExoPlayer? = null
    private lateinit var http: OkHttpClient

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        http = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        web = WebView(this)
        binding.webContainer.addView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString + " TSPlayerWeb/1.0"
        }
        web.webViewClient = object: WebViewClient() {}
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")

        // Carga UI local (reemplazala con tu /dist para que sea 1:1)
        web.loadUrl("file:///android_asset/web/index.html")

        ensurePlayer()
    }

    private inner class Bridge {
        @JavascriptInterface
        fun playChannel(json: String) {
            runOnUiThread {
                try {
                    val obj = org.json.JSONObject(json)
                    val id = obj.getString("id")
                    val url = obj.optString("url", "")
                    val finalUrl = if (url.isNotEmpty()) url else resolveSignedUrl(id)
                    play(finalUrl)
                } catch (e: Exception) { e.printStackTrace() }
            }
        }
        @JavascriptInterface fun pause() { runOnUiThread { player?.pause() } }
        @JavascriptInterface fun stop()  { runOnUiThread { player?.stop() } }
    }

    private fun resolveSignedUrl(id: String): String {
        // Construye URL firmada hacia tu backend /p/:id (la firma va en /channels realmente).
        // En tu web real, vas a pedir /channels y pasarás la url firmada aquí.
        val encId = URLEncoder.encode(id, "UTF-8")
        return "https://0880391e-8ff4-4235-8a95-6ee1e2eb1c4a-00-14tfrocqhbp3s.picard.replit.dev/p/" + encId + "?t=REEMPLAZAR_TOKEN"
    }

    private fun ensurePlayer() {
        if (player == null) player = ExoPlayer.Builder(this).build().also {
            binding.playerView.player = it
        }
    }

    private fun play(url: String) {
        val okFactory = OkHttpDataSource.Factory(http)
        val extractors = DefaultExtractorsFactory()
            .setTsExtractorFlags(
                TsExtractor.FLAG_ALLOW_NON_IDR_KEYFRAMES or TsExtractor.FLAG_DETECT_ACCESS_UNITS
            )
        val mediaSource = ProgressiveMediaSource.Factory(okFactory, extractors)
            .createMediaSource(MediaItem.fromUri(Uri.parse(url)))
        player!!.setMediaSource(mediaSource)
        player!!.prepare(); player!!.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.release(); player = null
    }
}