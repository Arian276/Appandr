package com.barriletecosmicotv

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BarrileteCosmicTVApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
    }
}