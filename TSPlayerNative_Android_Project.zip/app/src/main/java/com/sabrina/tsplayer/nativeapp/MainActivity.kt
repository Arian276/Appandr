
package com.sabrina.tsplayer.nativeapp

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.TsExtractor
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET

data class Channel(
    val id: String,
    val title: String? = null,
    val url: String,
)

interface Api {
    @GET("/channels")
    suspend fun channels(): List<Channel>
}

class ChannelsVM: ViewModel() {
    private val http = OkHttpClient.Builder().build()
    private val api = Retrofit.Builder()
        .baseUrl("https://0880391e-8ff4-4235-8a95-6ee1e2eb1c4a-00-14tfrocqhbp3s.picard.replit.dev")
        .addConverterFactory(MoshiConverterFactory.create())
        .client(http)
        .build()
        .create(Api::class.java)

    var channels by mutableStateOf<List<Channel>>(emptyList())
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun load() {
        viewModelScope.launch {
            runCatching { api.channels() }
                .onSuccess { channels = it; error = null }
                .onFailure { error = it.message }
        }
    }
}

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vm by viewModels<ChannelsVM>()
        setContent {
            MaterialTheme {
                AppScreen(vm) { url -> play(url) }
            }
        }
        vm.load()
    }

    private fun play(url: String) {
        if (player == null) {
            player = ExoPlayer.Builder(this).build()
        }
        val okFactory = OkHttpDataSource.Factory(OkHttpClient())
        val extractors = DefaultExtractorsFactory()
            .setTsExtractorFlags(TsExtractor.FLAG_ALLOW_NON_IDR_KEYFRAMES or TsExtractor.FLAG_DETECT_ACCESS_UNITS)
        val mediaSource = ProgressiveMediaSource.Factory(okFactory, extractors)
            .createMediaSource(MediaItem.fromUri(Uri.parse(url)))
        player!!.setMediaSource(mediaSource)
        player!!.prepare()
        player!!.play()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }
}

@Composable
fun AppScreen(vm: ChannelsVM, onPlay: (String) -> Unit) {
    var nowPlaying by remember { mutableStateOf<String?>(null) }
    Scaffold(topBar = {
        TopAppBar(title = { Text("TS Player") })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (vm.error != null) {
                Text("Error: " + vm.error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
            }
            if (vm.channels.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(vm.channels) { ch ->
                        ChannelRow(ch) {
                            nowPlaying = ch.id
                            onPlay(ch.url)
                        }
                    }
                }
                if (nowPlaying != null) {
                    Text("Reproduciendo: " + nowPlaying, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                }
            }
        }
    }
}

@Composable
fun ChannelRow(ch: Channel, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(ch.title ?: ch.id, style = MaterialTheme.typography.titleMedium)
            Text(ch.id, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Button(onClick = onClick) { Text("Ver") }
    }
}
