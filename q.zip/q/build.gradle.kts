plugins {
    id("com.android.application") version "8.6.1" apply false
    kotlin("android") version "2.0.0" apply false
}
