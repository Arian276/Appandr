package com.bc.tvappvlc.net

import com.squareup.moshi.Moshi
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

object ServiceLocator {

    /**
     * ⚠️ Cambia ESTA URL por la base real de tu servidor y debe terminar con "/".
     * Ejemplos:
     *   https://tudominio.com/
     *   https://cdn.tudominio.com/app/
     */
    private const val BASE_URL = "https://tu-dominio-o-cdn.com/"

    private val moshi by lazy { Moshi.Builder().build() }

    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(ApiService::class.java)
    }
}