package com.bc.tvappvlc

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.bc.tvappvlc.databinding.ActivityMainBinding
import com.bc.tvappvlc.model.Channel
import com.bc.tvappvlc.ui.ChannelAdapter
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val channels = mutableListOf<Channel>()
    private lateinit var adapter: ChannelAdapter

    // ⬇️ Poné acá tu endpoint real
    private val CONFIG_URL = "https://0880391e-8ff4-4235-8a95-6ee1e2eb1c4a-00-14tfrocqhbp3s.picard.replit.dev"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recycler.layoutManager = GridLayoutManager(this, 2)
        adapter = ChannelAdapter(channels) { channel ->
            val i = Intent(this, PlayerActivity::class.java)
            i.putExtra(PlayerActivity.EXTRA_URL, channel.url)
            startActivity(i)
        }
        binding.recycler.adapter = adapter

        // Intenta server primero, si falla usa assets
        fetchConfigFromServerOrAssets()
    }

    private fun fetchConfigFromServerOrAssets() {
        thread {
            val jsonText = download(CONFIG_URL) ?: runCatching {
                assets.open("channels.json").readBytes().toString(Charset.forName("UTF-8"))
            }.getOrNull()

            if (jsonText == null) {
                // Sin datos: no hacemos nada (o podrías mostrar un toast/snackbar)
                return@thread
            }

            // Dos formatos aceptados:
            // 1) Un arreglo JSON de canales (compat con tu assets/channels.json original)
            // 2) Un objeto con branding + "channels": [...]
            val (branding, channelList) = parseConfig(jsonText)

            runOnUiThread {
                applyBranding(branding)
                channels.clear()
                channels.addAll(channelList)
                adapter.notifyDataSetChanged()
            }
        }
    }

    private fun download(urlStr: String): String? = try {
        val url = URL(urlStr)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 15000
            requestMethod = "GET"
        }
        conn.inputStream.use { ins ->
            BufferedReader(InputStreamReader(ins)).readText()
        }
    } catch (_: Exception) {
        null
    }

    // Branding mínimo: nombre + color principal
    data class Branding(
        val appName: String? = null,
        val primaryColor: Int? = null
    )

    private fun parseConfig(text: String): Pair<Branding, List<Channel>> {
        // Si empieza con '[' asumimos el viejo formato: solo lista
        if (text.trimStart().startsWith("[")) {
            val arr = JSONArray(text)
            val list = mutableListOf<Channel>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Channel(o.getString("name"), o.getString("logo"), o.getString("url")))
            }
            return Branding() to list
        }

        // Formato nuevo con branding
        val obj = JSONObject(text)

        val appName = obj.optString("appName", null)

        // theme.seed: "#00C2A8"
        val theme = obj.optJSONObject("theme")
        val seedHex = theme?.optString("seed", null)
        val primary = try {
            seedHex?.let { Color.parseColor(it) }
        } catch (_: Exception) { null }

        val arr = obj.optJSONArray("channels") ?: JSONArray()
        val list = mutableListOf<Channel>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(Channel(o.getString("name"), o.getString("logo"), o.getString("url")))
        }

        return Branding(appName, primary) to list
    }

    private fun applyBranding(branding: Branding) {
        // Título de la Activity (lo verás en el conmutador de apps/pip)
        branding.appName?.let { title = it }

        // Color principal para los botones "Ver ahora"
        branding.primaryColor?.let { color ->
            ChannelAdapter.setAccentColor(color)
        }
    }
}