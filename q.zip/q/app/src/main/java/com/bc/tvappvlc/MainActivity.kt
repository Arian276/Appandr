package com.bc.tvappvlc

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.bc.tvappvlc.databinding.ActivityMainBinding
import com.bc.tvappvlc.model.Channel
import com.bc.tvappvlc.model.RemoteConfig
import com.bc.tvappvlc.net.ServiceLocator
import com.bc.tvappvlc.ui.ChannelAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.nio.charset.Charset

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val channels = mutableListOf<Channel>()
    private lateinit var adapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recycler.layoutManager = GridLayoutManager(this, 2)
        adapter = ChannelAdapter(channels) { channel ->
            val i = Intent(this, PlayerActivity::class.java)
            i.putExtra(PlayerActivity.EXTRA_URL, channel.url)
            startActivity(i)
        }
        binding.recycler.adapter = adapter

        // Descarga config del servidor (Retrofit) con fallback a assets/channels.json
        loadConfig()
    }

    private fun loadConfig() {
        lifecycleScope.launch {
            val config: RemoteConfig? = withContext(Dispatchers.IO) {
                runCatching { ServiceLocator.api.getConfig() }.getOrNull()
            }

            if (config != null && config.channels.isNotEmpty()) {
                applyBrandingFromConfig(config)
                channels.clear()
                channels.addAll(config.channels)
                adapter.notifyDataSetChanged()
            } else {
                // Fallback: leer lista local empaquetada
                val local = readLocalChannelsFallback()
                channels.clear()
                channels.addAll(local)
                adapter.notifyDataSetChanged()
            }
        }
    }

    private fun applyBrandingFromConfig(config: RemoteConfig) {
        // Nombre visible (toolbar / título de la Activity)
        config.branding?.display_name?.let { title = it }

        // Color principal (hex tipo "#00C2A8")
        config.branding?.primary_color?.let { hex ->
            runCatching { Color.parseColor(hex) }.getOrNull()?.let { color ->
                ChannelAdapter.setAccentColor(color)
            }
        }

        // Fondo opcional de la pantalla principal
        config.branding?.background_color?.let { hex ->
            runCatching { Color.parseColor(hex) }.getOrNull()?.let { color ->
                binding.root.setBackgroundColor(color)
            }
        }
    }

    private fun readLocalChannelsFallback(): List<Channel> {
        return runCatching {
            val jsonText = assets.open("channels.json").readBytes().toString(Charset.forName("UTF-8"))
            val arr = JSONArray(jsonText)
            val out = mutableListOf<Channel>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Channel(
                    name = o.getString("name"),
                    logo = o.getString("logo"),
                    url = o.getString("url")
                )
            }
            out
        }.getOrElse { emptyList() }
    }
}