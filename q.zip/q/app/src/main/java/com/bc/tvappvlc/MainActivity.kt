package com.bc.tvappvlc

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import coil.load
import com.bc.tvappvlc.databinding.ActivityMainBinding
import com.bc.tvappvlc.model.Channel
import com.bc.tvappvlc.model.RemoteConfig
import com.bc.tvappvlc.net.ServiceLocator
import com.bc.tvappvlc.ui.ChannelAdapter
import com.bc.tvappvlc.ui.GridSpacingItemDecoration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.nio.charset.Charset

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val channels = mutableListOf<Channel>()
    private lateinit var adapter: ChannelAdapter

    // Auto-refresh cada 15 minutos mientras la pantalla esté visible
    private val handler = Handler(Looper.getMainLooper())
    private val REFRESH_INTERVAL_MS = 15 * 60 * 1000L
    private val refreshTask = object : Runnable {
        override fun run() {
            loadConfig()
            handler.postDelayed(this, REFRESH_INTERVAL_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Toolbar como action bar
        setSupportActionBar(binding.toolbar)

        // Grid de 2 columnas con spacing
        binding.recycler.layoutManager = GridLayoutManager(this, 2)
        val spacing = resources.getDimensionPixelSize(R.dimen.bc_grid_spacing)
        binding.recycler.addItemDecoration(GridSpacingItemDecoration(2, spacing, true))

        adapter = ChannelAdapter(channels) { channel ->
            val i = Intent(this, PlayerActivity::class.java)
            i.putExtra(PlayerActivity.EXTRA_URL, channel.url)
            startActivity(i)
        }
        binding.recycler.adapter = adapter

        // Pull-to-refresh
        binding.swipeRefresh.setOnRefreshListener {
            loadConfig()
        }

        // Primera carga: intenta servidor con fallback a assets
        loadConfig()
    }

    override fun onStart() {
        super.onStart()
        handler.removeCallbacks(refreshTask)
        handler.postDelayed(refreshTask, REFRESH_INTERVAL_MS)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(refreshTask)
    }

    private fun loadConfig() {
        lifecycleScope.launch {
            val config: RemoteConfig? = withContext(Dispatchers.IO) {
                runCatching { ServiceLocator.api.getConfig() }.getOrNull()
            }

            if (config != null && config.channels.isNotEmpty()) {
                applyBrandingFromConfig(config)
                channels.clear()
                channels.addAll(config.channels)
                adapter.notifyDataSetChanged()
            } else {
                val local = readLocalChannelsFallback()
                channels.clear()
                channels.addAll(local)
                adapter.notifyDataSetChanged()
            }

            // Detener el spinner del SwipeRefresh si estaba activo
            binding.swipeRefresh.isRefreshing = false
        }
    }

    private fun applyBrandingFromConfig(config: RemoteConfig) {
        // Título visible (toolbar / activity)
        config.branding?.display_name?.let { title = it }

        // Banner (si viene URL, se muestra)
        val bannerUrl = config.branding?.banner_url
        if (!bannerUrl.isNullOrBlank()) {
            binding.banner.load(bannerUrl)
            binding.banner.visibility = android.view.View.VISIBLE
        } else {
            binding.banner.visibility = android.view.View.GONE
        }

        // Color principal (hex tipo "#00C2A8") para botón CTA
        // ⚠️ Deshabilitado para que no tape el degradado
        // config.branding?.primary_color?.let { hex ->
        //     runCatching { Color.parseColor(hex) }.getOrNull()?.let { color ->
        //         ChannelAdapter.setAccentColor(color)
        //     }
        // }

        // Fondo de la pantalla
        config.branding?.background_color?.let { hex ->
            runCatching { Color.parseColor(hex) }.getOrNull()?.let { color ->
                binding.root.setBackgroundColor(color)
            }
        }
    }

    private fun readLocalChannelsFallback(): List<Channel> {
        return runCatching {
            val jsonText = assets.open("channels.json")
                .readBytes()
                .toString(Charset.forName("UTF-8"))
            val arr = JSONArray(jsonText)
            val out = mutableListOf<Channel>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Channel(
                    name = o.optString("name"),
                    logo = o.optString("logo"),
                    url = o.optString("url"),
                    category = o.optString("category", null),
                    resolution = o.optString("resolution", null),
                    viewer_count = o.optInt("viewer_count", 0)
                )
            }
            out
        }.getOrElse { emptyList() }
    }
}