package com.bc.tvappvlc

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.bc.tvappvlc.databinding.ActivityMainBinding
import com.bc.tvappvlc.model.Channel
import com.bc.tvappvlc.ui.ChannelAdapter
import org.json.JSONArray
import java.nio.charset.Charset

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val channels = mutableListOf<Channel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recycler.layoutManager = GridLayoutManager(this, 2)
        val adapter = ChannelAdapter(channels) { channel ->
            val i = Intent(this, PlayerActivity::class.java)
            i.putExtra(PlayerActivity.EXTRA_URL, channel.url)
            startActivity(i)
        }
        binding.recycler.adapter = adapter
        loadChannels()
        adapter.notifyDataSetChanged()
    }

    private fun loadChannels() {
        val jsonText = assets.open("channels.json").readBytes().toString(Charset.forName("UTF-8"))
        val arr = JSONArray(jsonText)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            channels.add(Channel(o.getString("name"), o.getString("logo"), o.getString("url")))
        }
    }
}
