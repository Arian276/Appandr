package com.bc.tvappvlc.model

data class RemoteConfig(
    val meta: Meta? = null,
    val branding: Branding? = null,
    val layout: Layout? = null,
    val strings: Strings? = null,
    val header: Header? = null,
    val channels: List<Channel> = emptyList()
)

data class Meta(
    val version: Int? = null,
    val updated_at: String? = null
)

data class Branding(
    val display_name: String? = null,
    val subtitle: String? = null,
    val logo_url: String? = null,
    val banner_url: String? = null,

    // Compat anterior
    val primary_color: String? = null,
    val background_color: String? = null,
    val surface_color: String? = null,
    val on_surface_color: String? = null,

    // Nuevo esquema
    val colors: Colors? = null,
    val typography: Typography? = null,

    // Opcionales para toolbar
    val title_text_size_sp: Float? = null,
    val title_letter_spacing_em: Float? = null
)

data class Colors(
    val background: String? = null,
    val surface: String? = null,
    val surface_top: String? = null,
    val on_surface: String? = null,
    val border: String? = null,
    val muted: String? = null,
    val primary: String? = null,
    val primary_dark: String? = null,
    val accent: String? = null,
    val button_text: String? = null,
    val badge_bg: String? = null,
    val badge_text: String? = null,
    val ripple: String? = null
)

data class Typography(
    val font_family: String? = null,
    val font_urls: FontUrls? = null,
    val title_size_sp: Float? = null,
    val title_letter_spacing_em: Float? = null,
    val subtitle_size_sp: Float? = null,
    val body_size_sp: Float? = null
)

data class FontUrls(
    val regular: String? = null,
    val medium: String? = null,
    val bold: String? = null
)

data class Layout(
    val grid_columns: Int? = null,
    val grid_spacing_dp: Int? = null,
    val home: Home? = null,
    val card: Card? = null,
    val button: Button? = null,
    val badge: Badge? = null,
    val effects: Effects? = null
)

data class Home(
    val show_title: Boolean? = null,
    val show_banner: Boolean? = null
)

data class Card(
    val radius_dp: Int? = null,
    val elevation_dp: Int? = null,
    val stroke_width_dp: Int? = null,
    val stroke_color: String? = null,
    val image_ratio: String? = null,
    val background_style: String? = null, // flat | gradient | glass
    val gradient: CardGradient? = null,
    val halo_color: String? = null
)

data class CardGradient(
    val angle: Int? = null,
    val start: String? = null,
    val end: String? = null
)

data class Button(
    val text: String? = null,
    val radius_dp: Int? = null,
    val gradient_start: String? = null,
    val gradient_end: String? = null,
    val stroke_color: String? = null,
    val stroke_width_dp: Int? = null,
    val padding_h_dp: Int? = null,
    val padding_v_dp: Int? = null
)

data class Badge(
    val radius_dp: Int? = null,
    val padding_h_dp: Int? = null,
    val padding_v_dp: Int? = null
)

data class Effects(
    val background_gradients: List<BgGradient>? = null
)

data class BgGradient(
    val type: String? = null,       // radial
    val centerX: String? = null,    // "50%"
    val centerY: String? = null,
    val radius_dp: Int? = null,
    val start: String? = null,
    val end: String? = null
)

data class Header(
    val show_live_badge: Boolean? = null,
    val live_badge_text: String? = null,
    val live_bg: String? = null,
    val live_fg: String? = null
)

data class Channel(
    val id: String? = null,
    val name: String,
    val logo: String,
    val url: String,
    val category: String? = null,
    val resolution: String? = null,
    val viewer_count: Int = 0,
    val live: Boolean? = null
)