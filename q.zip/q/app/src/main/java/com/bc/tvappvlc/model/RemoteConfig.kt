package com.bc.tvappvlc.model

data class RemoteConfig(
    val meta: Meta? = null,
    val branding: Branding? = null,
    val channels: List<Channel> = emptyList(),
    val features: Features? = null
)

data class Meta(
    val version: Int? = null,
    val updated_at: String? = null
)

data class Branding(
    val display_name: String? = null,
    val primary_color: String? = null,
    val secondary_color: String? = null,
    val background_color: String? = null,
    val toolbar_title: String? = null,
    val banner_url: String? = null,
    val logo_url: String? = null
)

data class Features(
    val allow_pip: Boolean? = null,
    val show_search: Boolean? = null
)

data class Channel(
    val name: String,
    val url: String,
    val image: String
)