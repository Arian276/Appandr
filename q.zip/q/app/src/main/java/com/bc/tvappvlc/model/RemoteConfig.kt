package com.bc.tvappvlc

import android.graphics.Color
import com.bc.tvappvlc.model.RemoteConfig

object ThemeManager {

    private var theme: RemoteConfig.Branding.Theme? = null

    fun setFrom(remoteTheme: RemoteConfig.Branding.Theme?) {
        theme = remoteTheme
    }

    fun color(name: String): Int = when (name) {
        "primary"        -> parseOr("#00C2A8", theme?.primary)
        "onPrimary"      -> parseOr("#001F1A", theme?.onPrimary)
        "background"     -> parseOr("#101015", theme?.background)
        "surface"        -> parseOr("#15161B", theme?.surface)
        "surfaceVariant" -> parseOr("#1E222B", theme?.surfaceVariant)
        "onSurface"      -> parseOr("#DDE3EA", theme?.onSurface)
        else             -> Color.WHITE
    }

    private fun parseOr(fallback: String, hex: String?) =
        runCatching { Color.parseColor(hex ?: fallback) }
            .getOrElse { Color.parseColor(fallback) }
}