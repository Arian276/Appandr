package com.bc.tvappvlc.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.bc.tvappvlc.databinding.ItemChannelBinding
import com.bc.tvappvlc.model.Channel
import com.bc.tvappvlc.model.RemoteConfig

class ChannelAdapter(
    private val items: List<Channel>,
    private val onWatch: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    class VH(val binding: ItemChannelBinding) : RecyclerView.ViewHolder(binding.root)

    companion object {
        // Color de acento (branding)
        private var accentColor: Int? = null
        fun setAccentColor(color: Int) { accentColor = color }
    }

    // Texto del botón configurable desde el backend
    private var ctaText: String = "VER AHORA"

    /** Permite pasar el RemoteConfig para leer textos/colores sin depender de ThemeManager avanzado. */
    fun submitTheme(cfg: RemoteConfig?) {
        ctaText = cfg?.strings?.cta_watch ?: "VER AHORA"
        cfg?.branding?.theme?.primary?.let { hex ->
            runCatching { Color.parseColor(hex) }.getOrNull()?.let { setAccentColor(it) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val inflater = LayoutInflater.from(parent.context)
        return VH(ItemChannelBinding.inflate(inflater, parent, false))
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ch = items[position]
        val b = holder.binding

        // Logo
        b.imgLogo.load(ch.logo)

        // Nombre + categoría
        b.txtName.text = ch.name
        b.txtProvider.text = ch.category ?: "Deportes"

        // Calidad (ej. 1080p)
        if (!ch.resolution.isNullOrBlank()) {
            b.badgeQuality.text = ch.resolution
            b.badgeQuality.visibility = View.VISIBLE
        } else {
            b.badgeQuality.visibility = View.GONE
        }

        // Viewers
        if (ch.viewer_count > 0) {
            b.txtViewers.text = "${ch.viewer_count}"
            b.icViewers.visibility = View.VISIBLE
            b.txtViewers.visibility = View.VISIBLE
        } else {
            b.icViewers.visibility = View.GONE
            b.txtViewers.visibility = View.GONE
        }

        // Botón
        b.btnWatch.text = ctaText
        // Aplica tint del server si viene
        accentColor?.let { c ->
            b.btnWatch.backgroundTintList = ColorStateList.valueOf(c)
        }

        b.btnWatch.setOnClickListener { onWatch(ch) }
    }

    override fun getItemCount() = items.size
}