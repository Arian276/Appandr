package com.bc.tvappvlc.ui

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.bc.tvappvlc.databinding.ItemChannelBinding
import com.bc.tvappvlc.model.Channel

class ChannelAdapter(
    private val items: List<Channel>,
    private val onWatch: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    class VH(val binding: ItemChannelBinding) : RecyclerView.ViewHolder(binding.root)

    companion object {
        // Color de acento que puede setear el servidor (branding)
        private var accentColor: Int? = null
        fun setAccentColor(color: Int) { accentColor = color }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val inflater = LayoutInflater.from(parent.context)
        return VH(ItemChannelBinding.inflate(inflater, parent, false))
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ch = items[position]
        holder.binding.txtName.text = ch.name
        holder.binding.imgLogo.load(ch.logo)

        // Aplica color del servidor al botón si viene definido
        accentColor?.let { c ->
            holder.binding.btnWatch.backgroundTintList = ColorStateList.valueOf(c)
        }

        holder.binding.btnWatch.setOnClickListener { onWatch(ch) }
    }

    override fun getItemCount() = items.size
}