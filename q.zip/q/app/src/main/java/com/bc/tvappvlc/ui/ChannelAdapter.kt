package com.bc.tvappvlc.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.bc.tvappvlc.R
import com.bc.tvappvlc.model.Channel
import com.bc.tvappvlc.model.RemoteConfig
import com.bc.tvappvlc.theme.ThemeManager
import com.google.android.material.card.MaterialCardView

class ChannelAdapter(
    private val items: MutableList<Channel>,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.Holder>() {

    private var cfg: RemoteConfig? = null
    private var colors: ThemeManager.Colors? = null

    fun submitTheme(c: RemoteConfig) {
        cfg = c
        colors = null
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel, parent, false)
        return Holder(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: Holder, position: Int) {
        val ch = items[position]
        val ctx = h.itemView.context

        if (colors == null && cfg != null) {
            colors = ThemeManager.resolveColors(cfg!!, ctx)
        }

        // Imagen
        if (!ch.logo.isNullOrBlank()) h.logo.load(ch.logo) else h.logo.setImageDrawable(null)

        // Textos base
        h.name.text = ch.name
        h.provider.text = ch.category ?: "Deportes"

        // “Resolución” en el badge (si viene), si no lo ocultamos
        if (ch.resolution.isNullOrBlank()) {
            h.quality.visibility = View.GONE
        } else {
            h.quality.visibility = View.VISIBLE
            h.quality.text = ch.resolution
        }

        // CTA
        h.cta.text = cfg?.strings?.cta_watch ?: "VER AHORA"
        cfg?.layout?.card?.cta_text_size_sp?.let { h.cta.textSize = it.toFloat() }
        h.cta.setOnClickListener { onClick(ch) }
        h.card.setOnClickListener { onClick(ch) }

        // Colores desde ThemeManager
        colors?.let { c ->
            h.card.setCardBackgroundColor(c.surface)
            // stroke desde config si existe; si no, surfaceVariant como fallback
            val stroke = ThemeManager.color(
                cfg?.branding?.theme?.stroke_color,
                c.surfaceVariant
            )
            h.card.strokeColor = stroke

            h.name.setTextColor(c.onSurface)
            h.provider.setTextColor(c.muted)
            h.quality.setTextColor(c.onSurface)
            // Si quisieras pintar el fondo del CTA directamente:
            // h.cta.setBackgroundColor(c.primary)
            // h.cta.setTextColor(c.onPrimary)
        }
    }

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val card: MaterialCardView = v.findViewById(R.id.card)
        val logo: ImageView = v.findViewById(R.id.imgLogo)
        val name: TextView = v.findViewById(R.id.txtName)
        // En tu layout actual estos IDs existen:
        val provider: TextView = v.findViewById(R.id.txtProvider)      // subtítulo/categoría
        val quality: TextView = v.findViewById(R.id.badgeQuality)      // badge "1080p"
        val cta: TextView = v.findViewById(R.id.btnWatch)
    }
}