package com.bc.tvappvlc.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.bc.tvappvlc.R
import com.bc.tvappvlc.model.Channel
import com.bc.tvappvlc.model.RemoteConfig
import com.bc.tvappvlc.theme.ThemeManager

class ChannelAdapter(
    private val items: List<Channel>,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.Holder>() {

    private var cfg: RemoteConfig? = null
    private var colors: ThemeManager.Colors? = null

    fun submitTheme(c: RemoteConfig) {
        cfg = c
        colors = null
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel, parent, false)
        return Holder(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context

        if (colors == null && cfg != null) {
            colors = ThemeManager.resolveColors(cfg!!, context)
        }

        holder.logo.load(item.logo)
        holder.name.text = item.name
        holder.category.text = item.category ?: "General"
        holder.resolution.text = item.resolution ?: ""

        // Botón dinámico
        holder.cta.text = cfg?.strings?.cta_watch ?: "VER"
        holder.cta.setOnClickListener { onClick(item) }

        // Colores
        colors?.let {
            holder.card.setCardBackgroundColor(it.surface)
            holder.name.setTextColor(it.onSurface)
            holder.category.setTextColor(it.muted)
            holder.resolution.setTextColor(it.onSurface)
            holder.cta.setBackgroundColor(it.primary)
            holder.cta.setTextColor(it.onPrimary)
        }

        // Tipografía del botón
        cfg?.layout?.card?.let { card ->
            holder.cta.textSize = (card.cta_text_size_sp ?: 14).toFloat()
        }
    }

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val card: CardView = v.findViewById(R.id.cardView)
        val logo: ImageView = v.findViewById(R.id.imgLogo)
        val name: TextView = v.findViewById(R.id.txtName)
        val category: TextView = v.findViewById(R.id.txtCategory)
        val resolution: TextView = v.findViewById(R.id.txtResolution)
        val cta: Button = v.findViewById(R.id.btnWatch)
    }
}