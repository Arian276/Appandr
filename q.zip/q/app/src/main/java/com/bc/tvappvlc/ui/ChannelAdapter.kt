package com.bc.tvappvlc.ui

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.bc.tvappvlc.databinding.ItemChannelBinding
import com.bc.tvappvlc.model.Channel
import com.bc.tvappvlc.model.RemoteConfig
import com.bc.tvappvlc.theme.ThemeManager

class ChannelAdapter(
    private val items: List<Channel>,
    private val onWatch: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    class VH(val binding: ItemChannelBinding) : RecyclerView.ViewHolder(binding.root)

    private var cfg: RemoteConfig? = null
    fun submitTheme(config: RemoteConfig) { this.cfg = config }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val inflater = LayoutInflater.from(parent.context)
        return VH(ItemChannelBinding.inflate(inflater, parent, false))
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ch = items[position]
        val ctx = holder.itemView.context
        val res = ThemeManager.resolveColors(cfg ?: RemoteConfig(), ctx)

        // Card
        (holder.binding.card as? CardView)?.let {
            ThemeManager.styleCard(ctx, it, cfg ?: RemoteConfig(), res)
        }

        // Logo
        holder.binding.imgLogo.load(ch.logo)

        // Textos
        holder.binding.txtName.text = ch.name
        holder.binding.txtName.setTextColor(res.onSurface)

        holder.binding.txtProvider.text = ch.category ?: ""
        holder.binding.txtProvider.setTextColor(res.muted)

        // Badge calidad
        if (!ch.resolution.isNullOrBlank()) {
            holder.binding.badgeQuality.text = ch.resolution
            holder.binding.badgeQuality.visibility = View.VISIBLE
            holder.binding.badgeQuality.setTextColor(res.badgeText)
            holder.binding.badgeQuality.backgroundTintList = ColorStateList.valueOf(res.badgeBg)
        } else {
            holder.binding.badgeQuality.visibility = View.GONE
        }

        // Viewers
        if (holder.binding.txtViewers != null) {
            if (ch.viewer_count > 0) {
                holder.binding.txtViewers.text = "${ch.viewer_count} en vivo"
                holder.binding.txtViewers.setTextColor(res.muted)
                holder.binding.txtViewers.visibility = View.VISIBLE
            } else {
                holder.binding.txtViewers.visibility = View.GONE
            }
        }

        // Botón CTA
        val btn = holder.binding.btnWatch
        btn.text = cfg?.layout?.button?.text ?: "VER AHORA"
        btn.background = ThemeManager.buildButtonBackground(ctx, cfg ?: RemoteConfig(), res)
        btn.setTextColor(res.buttonText)

        val padH = ((cfg?.layout?.button?.padding_h_dp ?: 20) * ctx.resources.displayMetrics.density).toInt()
        val padV = ((cfg?.layout?.button?.padding_v_dp ?: 12) * ctx.resources.displayMetrics.density).toInt()
        btn.setPadding(padH, padV, padH, padV)

        btn.setOnClickListener { onWatch(ch) }
    }

    override fun getItemCount() = items.size
}