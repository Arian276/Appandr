package com.bc.tvappvlc.model

/**
 * ¡Dejar solo esta definición de Channel en el proyecto!
 * Si existe otra (duplicada) eliminála para evitar "Redeclaration: Channel".
 */
data class Channel(
    val id: String,
    val name: String,
    val logo: String,
    val url: String,
    val category: String? = null,   // proveedor/categoría (opcional)
    val quality: String? = null,    // ej. "1080p" (opcional)
    val viewers: Int? = null        // cantidad de espectadores (opcional)
)