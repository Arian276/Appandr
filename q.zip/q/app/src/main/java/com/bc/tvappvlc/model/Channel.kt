package com.bc.tvappvlc.model
data class Channel(val name:String,val logo:String,val url:String)
