package com.bc.tvappvlc.model

data class Channel(
    val name: String,
    val logo: String,
    val url: String,
    val category: String? = null,      // ej: "Deportes", "Noticias"
    val resolution: String? = null,    // ej: "1080p", "720p"
    val viewer_count: Int = 0          // cantidad de espectadores
)