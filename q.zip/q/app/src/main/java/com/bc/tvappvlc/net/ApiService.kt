package com.bc.tvappvlc.net

import com.bc.tvappvlc.model.RemoteConfig
import retrofit2.http.GET

interface ApiService {
    /**
     * Llama al endpoint que devuelve el archivo config.json
     * Ejemplo: https://tu-servidor/config.json
     */
    @GET("config.json")
    suspend fun getConfig(): RemoteConfig
}