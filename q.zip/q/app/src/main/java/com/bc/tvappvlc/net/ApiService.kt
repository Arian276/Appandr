package com.bc.tvappvlc.net

import com.bc.tvappvlc.model.RemoteConfig
import retrofit2.http.GET

interface ApiService {
    // El archivo que servirá tu backend (p.ej. https://tudominio.com/config.json)
    @GET("config.json")
    suspend fun getConfig(): RemoteConfig
}