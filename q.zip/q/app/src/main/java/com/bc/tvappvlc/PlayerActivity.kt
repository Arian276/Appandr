package com.bc.tvappvlc

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bc.tvappvlc.databinding.ActivityPlayerBinding
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

class PlayerActivity : AppCompatActivity() {

    companion object { const val EXTRA_URL = "url" }

    private lateinit var binding: ActivityPlayerBinding
    private lateinit var libVLC: LibVLC
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        libVLC = LibVLC(this, arrayListOf("--no-drop-late-frames", "--no-skip-frames"))
        mediaPlayer = MediaPlayer(libVLC)
        mediaPlayer?.attachViews(binding.video_surface, null, false, false)

        intent.getStringExtra(EXTRA_URL)?.let { play(it) }
    }

    private fun play(url: String) {
        mediaPlayer?.stop()
        val media = Media(libVLC, Uri.parse(url))
        media.setHWDecoderEnabled(true, false)
        media.addOption(":network-caching=1500")
        mediaPlayer?.media = media
        media.release()
        mediaPlayer?.play()
    }

    override fun onDestroy() {
        mediaPlayer?.stop()
        mediaPlayer?.detachViews()
        mediaPlayer?.release()
        libVLC.release()
        super.onDestroy()
    }
}
