package com.bc.tvappvlc

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import com.bc.tvappvlc.databinding.ActivityPlayerBinding
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_TITLE = "title"
    }

    private lateinit var binding: ActivityPlayerBinding
    private lateinit var libVLC: LibVLC
    private var mediaPlayer: MediaPlayer? = null
    private var controlsVisible = true
    private val hideHandler = Handler(Looper.getMainLooper())
    private val autoHide = Runnable { showControls(false) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Título del stream
        binding.title.text = intent.getStringExtra(EXTRA_TITLE) ?: "Reproduciendo"

        // VLC
        libVLC = LibVLC(this, arrayListOf("--no-drop-late-frames", "--no-skip-frames"))
        mediaPlayer = MediaPlayer(libVLC).apply {
            setEventListener { e ->
                runOnUiThread {
                    when (e.type) {
                        MediaPlayer.Event.Buffering ->
                            binding.buffering.visibility =
                                if (e.buffering == 100f) View.GONE else View.VISIBLE
                        MediaPlayer.Event.Playing -> {
                            binding.buffering.visibility = View.GONE
                            binding.btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)
                        }
                        MediaPlayer.Event.Paused ->
                            binding.btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
                        MediaPlayer.Event.Stopped, MediaPlayer.Event.EndReached -> {
                            binding.btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
                            binding.buffering.visibility = View.GONE
                        }
                    }
                }
            }
        }
        mediaPlayer?.attachViews(binding.videoSurface, null, false, false)

        // URL del intent
        intent.getStringExtra(EXTRA_URL)?.let { play(it) }

        // Gestos / botones
        binding.videoSurface.setOnClickListener { toggleControls() }
        binding.controls.setOnClickListener { /* consume click */ }

        binding.btnBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        binding.btnPlayPause.setOnClickListener {
            mediaPlayer?.let { mp ->
                if (mp.isPlaying) mp.pause() else mp.play()
                kickAutoHide()
            }
        }
        binding.btnMute.setOnClickListener {
            mediaPlayer?.let { mp ->
                val v = if (mp.volume > 0) 0 else 100
                mp.volume = v
                binding.btnMute.setImageResource(
                    if (v == 0) android.R.drawable.ic_lock_silent_mode
                    else android.R.drawable.ic_lock_silent_mode_off
                )
                kickAutoHide()
            }
        }
        binding.btnFull.setOnClickListener {
            val isLandscape =
                requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            setFullscreen(!isLandscape)
            kickAutoHide()
        }
        binding.btnTracks.setOnClickListener { showAudioSubDialog() }
        binding.btnQuality.setOnClickListener { showVideoQualityDialog() }

        kickAutoHide()
    }

    private fun play(url: String) {
        mediaPlayer?.stop()
        val media = Media(libVLC, Uri.parse(url)).apply {
            setHWDecoderEnabled(true, false)
            addOption(":network-caching=1500")
        }
        mediaPlayer?.media = media
        media.release()
        mediaPlayer?.play()
    }

    // ---------- Controles / UI ----------
    private fun toggleControls() = showControls(!controlsVisible)

    private fun showControls(show: Boolean) {
        controlsVisible = show
        binding.controls.animate()
            .alpha(if (show) 1f else 0f)
            .setDuration(160)
            .withEndAction {
                binding.controls.visibility = if (show) View.VISIBLE else View.GONE
            }.start()
        if (show) kickAutoHide() else hideHandler.removeCallbacks(autoHide)
    }

    private fun kickAutoHide() {
        hideHandler.removeCallbacks(autoHide)
        hideHandler.postDelayed(autoHide, 3000)
    }

    private fun setFullscreen(enable: Boolean) {
        requestedOrientation =
            if (enable) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (enable) {
            controller.hide(
                android.view.WindowInsets.Type.statusBars() or
                        android.view.WindowInsets.Type.navigationBars()
            )
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            controller.show(
                android.view.WindowInsets.Type.statusBars() or
                        android.view.WindowInsets.Type.navigationBars()
            )
        }
        window.decorView.setBackgroundColor(Color.BLACK)
    }

    // ---------- Diálogos ----------
    private fun showAudioSubDialog() {
        val mp = mediaPlayer ?: return
        val audios = mp.audioTracks
        val subs = mp.spuTracks
        val items = mutableListOf<Pair<Int, String>>()
        audios?.forEach { items += it.id to "Audio: ${it.name}" }
        subs?.forEach { items += it.id to "Subtítulo: ${it.name}" }
        if (items.isEmpty()) return
        val labels = items.map { it.second }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Pistas")
            .setItems(labels) { _, which ->
                val (id, label) = items[which]
                if (label.startsWith("Audio")) mp.audioTrack = id else mp.spuTrack = id
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun showVideoQualityDialog() {
        val mp = mediaPlayer ?: return
        val videos = mp.videoTracks ?: return
        if (videos.size <= 1) return
        val items = videos.mapIndexed { idx, t -> idx to (t.name ?: "Video ${idx}") }
        val labels = items.map { it.second }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Calidad")
            .setItems(labels) { _, which ->
                val track = videos[which]
                mp.videoTrack = track.id
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    override fun onDestroy() {
        hideHandler.removeCallbacksAndMessages(null)
        mediaPlayer?.stop()
        mediaPlayer?.detachViews()
        mediaPlayer?.release()
        libVLC.release()
        super.onDestroy()
    }
}