package com.bc.tvappvlc.theme

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ShapeDrawable
import android.util.TypedValue
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.bc.tvappvlc.model.*

/**
 * Aplica estilos dinámicos provenientes del backend (config.json).
 * Expone helpers para colores, tipografía, cards y botones.
 */
object ThemeManager {

    // -------- Helpers básicos

    private fun dp(ctx: Context, v: Int?): Int {
        if (v == null) return 0
        val d = ctx.resources.displayMetrics.density
        return (v * d).toInt()
    }

    private fun parseColor(hex: String?, fallback: Int): Int =
        try { Color.parseColor(hex) } catch (_: Exception) { fallback }

    private fun letterSpacing(em: Float?): Float = em ?: 0f

    // -------- API pública utilizada por MainActivity / Adapter

    /** Permite parsear un color HEX con fallback desde cualquier parte (MainActivity lo usa). */
    fun color(hex: String?, fallback: Int): Int = parseColor(hex, fallback)

    /** Colores resueltos de forma segura con fallbacks. */
    data class ColorsResolved(
        val background: Int,
        val surface: Int,
        val surfaceTop: Int,
        val onSurface: Int,
        val border: Int,
        val muted: Int,
        val primary: Int,
        val primaryDark: Int,
        val accent: Int,
        val buttonText: Int,
        val badgeBg: Int,
        val badgeText: Int,
        val ripple: Int
    )

    fun resolveColors(cfg: RemoteConfig, ctx: Context): ColorsResolved {
        val c = cfg.branding?.colors
        // compat con campos sueltos (background_color, surface_color, etc.)
        return ColorsResolved(
            background = parseColor(c?.background ?: cfg.branding?.background_color, Color.parseColor("#0B0F14")),
            surface    = parseColor(c?.surface ?: cfg.branding?.surface_color,     Color.parseColor("#161B22")),
            surfaceTop = parseColor(c?.surface_top,                                Color.parseColor("#1C232C")),
            onSurface  = parseColor(c?.on_surface ?: cfg.branding?.on_surface_color, Color.parseColor("#E8EDF2")),
            border     = parseColor(c?.border,                                     Color.parseColor("#2B3440")),
            muted      = parseColor(c?.muted,                                      Color.parseColor("#AAB4BE")),
            primary    = parseColor(c?.primary ?: cfg.branding?.primary_color,     Color.parseColor("#67E8F9")),
            primaryDark= parseColor(c?.primary_dark,                               Color.parseColor("#00B7E6")),
            accent     = parseColor(c?.accent,                                     Color.parseColor("#FFA54D")),
            buttonText = parseColor(c?.button_text,                                Color.WHITE),
            badgeBg    = parseColor(c?.badge_bg,                                   Color.parseColor("#27313A")),
            badgeText  = parseColor(c?.badge_text,                                 Color.parseColor("#E9EEF2")),
            ripple     = parseColor(c?.ripple,                                     Color.parseColor("#33FFFFFF"))
        )
    }

    /** Aplica tamaño y letter-spacing al TextView del título de la Toolbar. */
    fun applyToolbarTitleStyle(titleView: TextView?, cfg: RemoteConfig) {
        if (titleView == null) return
        val sizeSp = cfg.branding?.title_text_size_sp ?: cfg.branding?.typography?.title_size_sp
        val spacingEm = cfg.branding?.title_letter_spacing_em ?: cfg.branding?.typography?.title_letter_spacing_em
        if (sizeSp != null) titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        if (spacingEm != null) titleView.letterSpacing = letterSpacing(spacingEm)
    }

    /** Construye el fondo del botón CTA con gradiente, radio y stroke desde el layout.button */
    fun buildButtonBackground(ctx: Context, cfg: RemoteConfig, colors: ColorsResolved): GradientDrawable {
        val b = cfg.layout?.button
        val start = parseColor(b?.gradient_start, colors.primary)
        val end   = parseColor(b?.gradient_end,   colors.primaryDark)
        val gd = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(start, end))
        gd.cornerRadius = dp(ctx, b?.radius_dp).toFloat()
        val strokeColor = parseColor(b?.stroke_color, Color.parseColor("#33FFFFFF"))
        val strokeWidth = dp(ctx, b?.stroke_width_dp ?: 1)
        gd.setStroke(strokeWidth, strokeColor)
        return gd
    }

    /** Aplica estilo completo a una Card (fondo liso o gradiente, radius, elevación y borde). */
    fun styleCard(ctx: Context, card: CardView, cfg: RemoteConfig, colors: ColorsResolved) {
        val c = cfg.layout?.card
        val radius = dp(ctx, c?.radius_dp)
        val elevation = dp(ctx, c?.elevation_dp)
        card.radius = radius.toFloat()
        card.cardElevation = elevation.toFloat()

        val style = c?.background_style ?: "flat"
        val bg = when (style) {
            "gradient" -> {
                val start = parseColor(c?.gradient?.start, colors.surfaceTop)
                val end = parseColor(c?.gradient?.end, colors.surface)
                GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(start, end)).apply {
                    cornerRadius = radius.toFloat()
                }
            }
            else -> {
                GradientDrawable().apply {
                    setColor(colors.surface)
                    cornerRadius = radius.toFloat()
                }
            }
        }
        card.background = bg

        // Borde sutil con foreground (CardView no tiene stroke propio)
        val strokeColor = parseColor(c?.stroke_color, colors.border)
        card.foreground = ShapeDrawable().apply {
            paint.color = strokeColor
            alpha = 32 // ~12.5% (sutil)
        }

        card.preventCornerOverlap = true
        card.useCompatPadding = true
    }
}