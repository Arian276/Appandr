package com.bc.tvappvlc.theme

import android.content.Context
import android.graphics.Color
import android.widget.TextView
import com.bc.tvappvlc.model.RemoteConfig

/**
 * ThemeManager mínimo y seguro:
 * - Resuelve colores desde el JSON con defaults.
 * - Aplica color y (si está) tamaño/letterSpacing del título del toolbar.
 */
object ThemeManager {

    data class Colors(
        val background: Int,
        val surface: Int,
        val onSurface: Int,
        val primary: Int,
        val muted: Int
    )

    /** Parse de color hex con fallback. Acepta "#RRGGBB" / "#AARRGGBB". */
    fun color(hex: String?, fallback: Int): Int =
        runCatching { Color.parseColor(hex) }.getOrElse { fallback }

    /** Colores principales usados por la app. */
    fun resolveColors(cfg: RemoteConfig?, context: Context): Colors {
        val t = cfg?.branding?.theme
        val background = color(t?.background, Color.parseColor("#101015"))
        val surface    = color(t?.surface,    Color.parseColor("#15161B"))
        val onSurface  = color(t?.onSurface,  Color.parseColor("#DDE3EA"))
        val primary    = color(t?.primary ?: t?.seed, Color.parseColor("#00C2A8"))
        val muted      = color(t?.muted,      Color.parseColor("#9AA4AF"))
        return Colors(background, surface, onSurface, primary, muted)
    }

    /**
     * Aplica estilo al título del Toolbar si el backend envió algo opcional como:
     *   branding.theme.title_size_sp (Number)
     *   branding.theme.title_letter_spacing_em (Number)
     * No “rompe” si no existen: todo va en runCatching.
     */
    fun applyToolbarTitleStyle(tv: TextView?, cfg: RemoteConfig?) {
        if (tv == null) return
        val colors = resolveColors(cfg, tv.context)
        tv.setTextColor(colors.onSurface)

        // Tamaño (SP) opcional
        runCatching {
            val theme = cfg?.branding?.theme ?: return@runCatching
            val f = theme.javaClass.getDeclaredField("title_size_sp")
            f.isAccessible = true
            val value = (f.get(theme) as? Number)?.toFloat()
            if (value != null) tv.textSize = value
        }

        // Letter spacing (EM) opcional
        runCatching {
            val theme = cfg?.branding?.theme ?: return@runCatching
            val f = theme.javaClass.getDeclaredField("title_letter_spacing_em")
            f.isAccessible = true
            val value = (f.get(theme) as? Number)?.toFloat()
            if (value != null) tv.letterSpacing = value
        }
    }
}