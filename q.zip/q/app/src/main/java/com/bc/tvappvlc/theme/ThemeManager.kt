package com.bc.tvappvlc.theme

import android.content.Context
import android.graphics.Color
import android.widget.TextView
import com.bc.tvappvlc.model.RemoteConfig

object ThemeManager {

    data class Colors(
        val primary: Int,
        val onPrimary: Int,
        val background: Int,
        val surface: Int,
        val surfaceVariant: Int,
        val onSurface: Int,
        val muted: Int
    )

    fun resolveColors(cfg: RemoteConfig, ctx: Context): Colors {
        val b = cfg.branding?.theme
        return Colors(
            primary = color(b?.primary, Color.parseColor("#00C2A8")),
            onPrimary = color(b?.onPrimary, Color.WHITE),
            background = color(b?.background, Color.parseColor("#101015")),
            surface = color(b?.surface, Color.parseColor("#15161B")),
            surfaceVariant = color(b?.surfaceVariant, Color.parseColor("#1E222B")),
            onSurface = color(b?.onSurface, Color.parseColor("#DDE3EA")),
            muted = color(b?.muted, Color.GRAY)
        )
    }

    fun color(hex: String?, fallback: Int): Int {
        return try {
            if (hex.isNullOrBlank()) fallback else Color.parseColor(hex)
        } catch (e: Exception) {
            fallback
        }
    }

    fun applyToolbarTitleStyle(view: TextView?, cfg: RemoteConfig) {
        if (view == null) return
        val typo = cfg.typography
        view.textSize = (typo?.title_size_sp ?: 20).toFloat()
        view.letterSpacing = (typo?.title_letter_spacing_em ?: 0f)
        view.setTextColor(color(typo?.title_color, Color.WHITE))
    }
}