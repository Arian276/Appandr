package com.bc.tvappvlc.theme

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.bc.tvappvlc.model.*
import kotlin.math.roundToInt

object ThemeManager {

    // ---- Helpers
    private fun dp(ctx: Context, v: Int?): Int = ((v ?: 0) * ctx.resources.displayMetrics.density).roundToInt()
    private fun color(hex: String?, fallback: Int): Int = try { Color.parseColor(hex) } catch (_: Exception) { fallback }
    private fun letterSpacing(em: Float?): Float = em ?: 0f

    // ---- Expuestos
    data class ColorsResolved(
        val background: Int,
        val surface: Int,
        val surfaceTop: Int,
        val onSurface: Int,
        val border: Int,
        val muted: Int,
        val primary: Int,
        val primaryDark: Int,
        val accent: Int,
        val buttonText: Int,
        val badgeBg: Int,
        val badgeText: Int,
        val ripple: Int
    )

    fun resolveColors(cfg: RemoteConfig, ctx: Context): ColorsResolved {
        val c = cfg.branding?.colors
        return ColorsResolved(
            background = color(c?.background ?: cfg.branding?.background_color, Color.parseColor("#0B0F14")),
            surface    = color(c?.surface ?: cfg.branding?.surface_color, Color.parseColor("#161B22")),
            surfaceTop = color(c?.surface_top, Color.parseColor("#1C232C")),
            onSurface  = color(c?.on_surface ?: cfg.branding?.on_surface_color, Color.parseColor("#E8EDF2")),
            border     = color(c?.border, Color.parseColor("#2B3440")),
            muted      = color(c?.muted, Color.parseColor("#AAB4BE")),
            primary    = color(c?.primary ?: cfg.branding?.primary_color, Color.parseColor("#67E8F9")),
            primaryDark= color(c?.primary_dark, Color.parseColor("#00B7E6")),
            accent     = color(c?.accent, Color.parseColor("#FFA54D")),
            buttonText = color(c?.button_text, Color.WHITE),
            badgeBg    = color(c?.badge_bg, Color.parseColor("#27313A")),
            badgeText  = color(c?.badge_text, Color.parseColor("#E9EEF2")),
            ripple     = color(c?.ripple, Color.parseColor("#33FFFFFF"))
        )
    }

    suspend fun resolveTypeface(ctx: Context, cfg: RemoteConfig): Typeface? {
        // Si querés implementar fuentes remotas, usá RemoteFontLoader (abajo).
        // Por ahora devolvemos null => usa la fuente del sistema / Inter instalada.
        return null
    }

    fun buildButtonBackground(ctx: Context, cfg: RemoteConfig, colors: ColorsResolved): GradientDrawable {
        val b = cfg.layout?.button
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                color(b?.gradient_start, colors.primary),
                color(b?.gradient_end, colors.primaryDark)
            )
        )
        gd.cornerRadius = dp(ctx, b?.radius_dp).toFloat()
        val strokeColor = color(b?.stroke_color, Color.parseColor("#33FFFFFF"))
        val strokeWidth = dp(ctx, b?.stroke_width_dp)
        gd.setStroke(strokeWidth, strokeColor)
        return gd
    }

    fun applyToolbarTitleStyle(titleView: TextView?, cfg: RemoteConfig) {
        if (titleView == null) return
        val size = cfg.branding?.title_text_size_sp ?: cfg.branding?.typography?.title_size_sp
        val spacing = cfg.branding?.title_letter_spacing_em ?: cfg.branding?.typography?.title_letter_spacing_em
        if (size != null) titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        if (spacing != null) titleView.letterSpacing = letterSpacing(spacing)
    }

    fun styleCard(ctx: Context, card: CardView, cfg: RemoteConfig, colors: ColorsResolved) {
        val c = cfg.layout?.card
        card.radius = dp(ctx, c?.radius_dp).toFloat()
        card.cardElevation = dp(ctx, c?.elevation_dp).toFloat()
        // background
        val style = c?.background_style ?: "flat"
        val bg = when (style) {
            "gradient" -> GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(color(c?.gradient?.start, colors.surfaceTop), color(c?.gradient?.end, colors.surface))
            ).apply { cornerRadius = card.radius }
            else -> GradientDrawable().apply {
                setColor(colors.surface)
                cornerRadius = card.radius
            }
        }
        card.background = bg
        // stroke como borde usando compat (CardView no tiene stroke, usamos foreground)
        val strokeColor = color(c?.stroke_color, colors.border)
        val strokeWidth = dp(ctx, c?.stroke_width_dp ?: 1)
        card.foreground = ShapeDrawable().apply {
            paint.color = strokeColor
            // CardView no soporta stroke directo; dejamos foreground solo si querés overlay sutil
            alpha = 40
        }
        card.preventCornerOverlap = true
        card.useCompatPadding = true
    }

    fun rippleFrom(colors: ColorsResolved): IntArray {
        return intArrayOf(colors.ripple)
    }
}