package com.appandr.app.model

data class Brand(
    val primary: String? = null,
    val background: String? = null,
    val onBackground: String? = null
)

data class Banners(
    val home: String? = null
)

/**
 * Ejemplo esperado de /config:
 * {
 *   "brand": {"primary":"#0EA5E9","background":"#0B1220","onBackground":"#FFFFFF"},
 *   "banners": {"home":"https://.../banner.png"},
 *   "useLogoEndpoint": true
 * }
 */
data class Config(
    val brand: Brand? = null,
    val banners: Banners? = null,
    val useLogoEndpoint: Boolean? = null
)