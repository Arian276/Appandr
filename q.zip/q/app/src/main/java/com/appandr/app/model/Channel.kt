package com.appandr.app.model

data class Channel(
    val id: String,
    val title: String,
    val url: String,
    val logo: String?
)