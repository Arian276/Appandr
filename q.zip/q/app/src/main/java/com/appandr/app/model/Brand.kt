package com.appandr.app.model

data class Brand(
    val primary: String? = null,
    val background: String? = null,
    val onBackground: String? = null
)