package com.appandr.app.model

data class Banners(
    val home: String? = null
)