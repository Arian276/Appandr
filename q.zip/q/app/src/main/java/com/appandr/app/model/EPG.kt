package com.appandr.app.model

/**
 * Ejemplo esperado de /epg?channel=<id>:
 * [
 *   {"start":"2025-09-18T14:00:00Z","end":"2025-09-18T16:00:00Z","title":"Partido A vs B","description":"Fecha 5"},
 *   {"start":"2025-09-18T16:00:00Z","end":"2025-09-18T18:00:00Z","title":"Post partido","description":null}
 * ]
 */
data class EPGEntry(
    val start: String,
    val end: String,
    val title: String,
    val description: String? = null
)