package com.appandr.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import com.appandr.app.model.Channel
import com.appandr.app.model.Config
import com.appandr.app.model.EPGEntry
import com.appandr.app.model.Brand
import com.appandr.app.model.Banners
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.lang.Integer.min

class MainActivity : ComponentActivity() {

    companion object {
        private const val BASE_URL =
            "https://0880391e-8ff4-4235-8a95-6ee1e2eb1c4a-00-14tfrocqhbp3s.picard.replit.dev"

        private const val CHANNELS_URL = "$BASE_URL/channels"
        private const val CONFIG_URL = "$BASE_URL/config"

        private fun epgUrl(channelId: String) = "$BASE_URL/epg?channel=$channelId"
        private fun logoUrl(channelId: String) = "$BASE_URL/logos/$channelId.png"
    }

    private val http by lazy { OkHttpClient() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Estado: config + canales
            var config by remember { mutableStateOf<Config?>(null) }
            var channels by remember { mutableStateOf(emptyList<Channel>()) }
            var loading by remember { mutableStateOf(true) }

            LaunchedEffect(Unit) {
                // Cargamos config y canales desde tu backend
                config = fetchConfig()
                channels = fetchChannels()
                loading = false
            }

            val scheme = makeColorScheme(config)
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize()) {
                    if (loading) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else {
                        ChannelScreen(
                            config = config,
                            channels = channels,
                            onRefresh = {
                                loading = true
                                channels = fetchChannels()
                                loading = false
                            },
                            onPlay = { url ->
                                val i = Intent(this, PlayerActivity::class.java)
                                i.putExtra("url", url)
                                startActivity(i)
                            },
                            onFetchEpg = { id -> fetchEpg(id) },
                            buildLogoUrl = { id ->
                                // Si no hay logo en el JSON y el server habilit� logo endpoint
                                if (config?.useLogoEndpoint == true) logoUrl(id) else null
                            }
                        )
                    }
                }
            }
        }
    }

    // -------------------
    // Networking helpers
    // -------------------
    private fun fetchConfig(): Config? = try {
        val req = Request.Builder().url(CONFIG_URL).build()
        val resp = http.newCall(req).execute()
        val body = resp.body?.string().orEmpty()
        val o = JSONObject(body)

        val brandObj = o.optJSONObject("brand")
        val bannersObj = o.optJSONObject("banners")

        Config(
            brand = if (brandObj != null)
                Brand(
                    primary = brandObj.optString("primary", null),
                    background = brandObj.optString("background", null),
                    onBackground = brandObj.optString("onBackground", null)
                ) else null,
            banners = if (bannersObj != null)
                Banners(home = bannersObj.optString("home", null))
            else null,
            useLogoEndpoint = o.optBoolean("useLogoEndpoint", false)
        )
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }

    private fun fetchChannels(): List<Channel> = try {
        val req = Request.Builder().url(CHANNELS_URL).build()
        val resp = http.newCall(req).execute()
        val body = resp.body?.string().orEmpty()
        val arr = JSONArray(body)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    Channel(
                        id = o.optString("id", i.toString()),
                        title = o.optString("title", "Canal $i"),
                        url = o.optString("url"),
                        logo = o.optString("logo", null)
                    )
                )
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
        // Fallback m�nimo si el backend no responde
        listOf(
            Channel("espn", "ESPN Premium HD", "http://190.95.60.228:8500/play/a09v", null),
            Channel("espn2", "ESPN HD", "http://190.95.60.228:8500/play/a013", null)
        )
    }

    private fun fetchEpg(channelId: String): List<EPGEntry> = try {
        val req = Request.Builder().url(epgUrl(channelId)).build()
        val resp = http.newCall(req).execute()
        val body = resp.body?.string().orEmpty()
        val arr = JSONArray(body)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    EPGEntry(
                        start = o.optString("start"),
                        end = o.optString("end"),
                        title = o.optString("title"),
                        description = o.optString("description", null)
                    )
                )
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
        emptyList()
    }
}

// -------------------
// UI composables
// -------------------
@Composable
private fun ChannelScreen(
    config: Config?,
    channels: List<Channel>,
    onRefresh: () -> Unit,
    onPlay: (String) -> Unit,
    onFetchEpg: (String) -> List<com.appandr.app.model.EPGEntry>,
    buildLogoUrl: (String) -> String?
) {
    Column(Modifier.fillMaxSize()) {
        // Banner superior opcional desde /config
        val banner = config?.banners?.home
        if (!banner.isNullOrBlank()) {
            AsyncImage(
                model = banner,
                contentDescription = "banner",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .padding(bottom = 8.dp)
            )
        }

        // Lista de canales
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(channels) { ch ->
                ChannelCard(
                    ch = ch,
                    fallbackLogo = buildLogoUrl(ch.id),
                    onPlay = onPlay,
                    onFetchEpg = onFetchEpg
                )
            }
        }
    }
}

@Composable
private fun ChannelCard(
    ch: Channel,
    fallbackLogo: String?,
    onPlay: (String) -> Unit,
    onFetchEpg: (String) -> List<EPGEntry>
) {
    var epg by remember(ch.id) { mutableStateOf<List<EPGEntry>?>(null) }
    var loadingEpg by remember(ch.id) { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val logoToShow = ch.logo ?: fallbackLogo
                if (!logoToShow.isNullOrBlank()) {
                    AsyncImage(
                        model = logoToShow,
                        contentDescription = ch.title,
                        modifier = Modifier.size(56.dp)
                    )
                } else {
                    Box(Modifier.size(56.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        ch.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        ch.url,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.width(12.dp))
                Button(onClick = { onPlay(ch.url) }) { Text("Ver") }
            }

            Spacer(Modifier.height(8.dp))

            // Bot�n para cargar/ver EPG
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = {
                    if (epg == null && !loadingEpg) {
                        loadingEpg = true
                        // Cargar EPG on-demand
                        epg = onFetchEpg(ch.id)
                        loadingEpg = false
                    } else {
                        // toggle: si ya est�, ocultamos
                        epg = null
                    }
                }) {
                    Text(if (epg == null) "Ver EPG" else "Ocultar EPG")
                }
                if (loadingEpg) {
                    Spacer(Modifier.width(8.dp))
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                }
            }

            // Lista EPG (primeros 3 items para no saturar)
            epg?.let { list ->
                val showN = min(3, list.size)
                for (i in 0 until showN) {
                    val item = list[i]
                    Text("� ${item.title}", style = MaterialTheme.typography.bodyMedium)
                    Text("${item.start}  ${item.end}", style = MaterialTheme.typography.bodySmall)
                    item.description?.takeIf { it.isNotBlank() }?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall)
                    }
                    if (i < showN - 1) Spacer(Modifier.height(4.dp))
                }
            }
        }
    }
}

// -------------------
// Theming din�mico desde /config
// -------------------
@Composable
private fun makeColorScheme(config: Config?): ColorScheme {
    // Valores por defecto (oscuro)
    val fallback = darkColorScheme()
    if (config?.brand == null) return fallback

    fun parse(hex: String?): androidx.compose.ui.graphics.Color? {
        if (hex.isNullOrBlank()) return null
        val clean = hex.removePrefix("#")
        return try {
            val color = android.graphics.Color.parseColor("#$clean")
            androidx.compose.ui.graphics.Color(color)
        } catch (_: Exception) {
            null
        }
    }

    val primary = parse(config.brand.primary) ?: fallback.primary
    val background = parse(config.brand.background) ?: fallback.background
    val onBackground = parse(config.brand.onBackground) ?: fallback.onBackground

    return fallback.copy(
        primary = primary,
        background = background,
        surface = background,
        onBackground = onBackground,
        onSurface = onBackground
    )
}