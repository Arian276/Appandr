package com.appandr.app

import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView: WebView = findViewById(R.id.webview)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        // Cliente para interceptar URLs
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url.toString()
                // Si es .m3u8 o .ts → lo abrís con PlayerActivity
                if (url.endsWith(".m3u8") || url.endsWith(".ts")) {
                    val intent = android.content.Intent(this@MainActivity, PlayerActivity::class.java)
                    intent.putExtra("url", url)
                    startActivity(intent)
                    return true
                }
                return false // el resto lo abre en el mismo WebView
            }
        }

        // 👉 Acá tu dominio exacto
        webView.loadUrl("https://0880391e-8ff4-4235-8a95-6ee1e2eb1c4a-00-14tfrocqhbp3s.picard.replit.dev/")
    }
}