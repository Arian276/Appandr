
package com.appandr.native

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

val Bg = Color(0xFF0F141A)
val Fg = Color(0xFFFAFAFA)
val Primary = Color(0xFF5ACCF2)
val Accent = Color(0xFFFA832E)
val Card = Color(0xFF2A2F32)
val Muted = Color(0xFFA9A4A2)

class MainActivity : ComponentActivity() {{
    override fun onCreate(savedInstanceState: Bundle?) {{
        super.onCreate(savedInstanceState)
        setContent {{
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Primary,
                secondary = Accent,
                background = Bg,
                surface = Card,
                onBackground = Fg,
                onSurface = Fg
            )) {{
                AppHome(loadChannels = {{ ApiClient.api.channels() }}) {{ url, title ->
                    val i = Intent(this, PlayerActivity::class.java).apply {{
                        putExtra("url", url)
                        putExtra("title", title ?: "")
                    }}
                    startActivity(i)
                }}
            }}
        }}
    }}
}}

@Composable
fun AppHome(loadChannels: suspend ()->List<Channel>, onPlay:(String,String?)->Unit) {{
    var channels by remember {{ mutableStateOf<List<Channel>?>(null) }}
    var error by remember {{ mutableStateOf<String?>(null) }}
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {{
        scope.launch {{
            runCatching {{ loadChannels() }}
                .onSuccess {{ channels = it }}
                .onFailure {{ error = it.message }}
        }}
    }}

    Scaffold(topBar = {{
        TopAppBar(title = {{ Text("Appandr", color = Fg) }}, colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Bg
        ))
    }}, containerColor = Bg) {{ padding ->
        Column(Modifier.fillMaxSize().background(Bg).padding(padding)) {{
            if (error != null) {{
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {{
                    Text(text = "Error: " + error!!, color = Color.Red)
                }}
            }} else if (channels == null) {{
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {{
                    CircularProgressIndicator(color = Primary)
                }}
            }} else {{
                LazyColumn(Modifier.fillMaxSize()) {{
                    items(channels!!) {{ ch ->
                        ChannelRow(ch) {{ onPlay(ch.url, ch.title) }}
                    }}
                }}
            }}
        }}
    }}
}}

@Composable
fun ChannelRow(ch: Channel, onClick:()->Unit) {{
    Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp)
        .clickable {{ onClick() }}) {{
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {{
            AsyncImage(model = ch.logo, contentDescription = ch.title, modifier = Modifier.size(56.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {{
                Text(ch.title ?: ch.id, color = Fg, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(ch.id, color = Muted, style = MaterialTheme.typography.bodySmall)
            }}
            Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Primary)) {{
                Text("Ver", color = Color.Black, fontWeight = FontWeight.SemiBold)
            }}
        }}
    }}
}}
