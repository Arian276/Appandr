
package com.appandr.native

import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import android.view.WindowManager

class PlayerActivity : ComponentActivity() {
    private var libVlc: LibVLC? = null
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var video: VLCVideoLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        video = VLCVideoLayout(this)
        setContentView(video, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val url = intent.getStringExtra("url") ?: return
        val opts = arrayListOf(
            "--network-caching=1000",
            "--rtsp-tcp",
            "--no-drop-late-frames",
            "--no-skip-frames"
        )
        libVlc = LibVLC(this, opts)
        mediaPlayer = MediaPlayer(libVlc)
        mediaPlayer!!.attachViews(video, null, false, false)

        val media = Media(libVlc, android.net.Uri.parse(url))
        media.setHWDecoderEnabled(true, true)
        media.addOption(":input-fast-seek")
        media.addOption(":clock-jitter=0")
        media.addOption(":clock-synchro=0")
        mediaPlayer!!.media = media

        mediaPlayer!!.play()
    }

    override fun onStop() {
        super.onStop()
        mediaPlayer?.stop()
        mediaPlayer?.detachViews()
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        libVlc?.release()
    }
}
