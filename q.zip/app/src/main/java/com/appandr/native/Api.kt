
package com.appandr.native

import retrofit2.http.GET
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import okhttp3.OkHttpClient

interface Api {
    @GET("/channels")
    suspend fun channels(): List<Channel>
}

object ApiClient {
    private val http = OkHttpClient.Builder().build()
    val api: Api = Retrofit.Builder()
        .baseUrl("https://0880391e-8ff4-4235-8a95-6ee1e2eb1c4a-00-14tfrocqhbp3s.picard.replit.dev")
        .addConverterFactory(MoshiConverterFactory.create())
        .client(http)
        .build()
        .create(Api::class.java)
}
